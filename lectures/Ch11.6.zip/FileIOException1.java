import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileIOException1 {

	public static void main(String[] args) {

		// Initialize output file object
		try
		{
			// Open file for writing
			FileWriter fw = new FileWriter("test.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);

			// Write a string 
			pw.println("Hello world");
		
			// Close file stream
			pw.close();
		}
		catch(IOException e)
		{
			System.err.println("I/O EXCEPTION DURING WRITING: " + e.getMessage());
		}
		
		// Initialize input file object
		try
		{
			// Open file for reading
			FileReader fr = new FileReader("test.txt");
			BufferedReader br = new BufferedReader(fr);
		
			// Read a string
			Scanner scan = new Scanner(br);
			String str = scan.next();
			System.out.println("Read string: " + str);
		
			// Close file stream
			br.close();
		}
		catch(IOException e)
		{
			System.err.println("I/O EXCEPTION DURING READING: " + e.getMessage());
		}
	}
}
