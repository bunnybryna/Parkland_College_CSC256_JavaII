package lab5Pack;

public interface Priority {
	public void setPriority (int priority);
	public int getPriority();

}
