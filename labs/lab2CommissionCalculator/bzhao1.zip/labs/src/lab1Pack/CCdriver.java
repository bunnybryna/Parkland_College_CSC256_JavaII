package lab1Pack;

public class CCdriver {

	public static void main(String[] args) {
		CommissionCalculator cc = new CommissionCalculator();
		cc.run();

	}

}
