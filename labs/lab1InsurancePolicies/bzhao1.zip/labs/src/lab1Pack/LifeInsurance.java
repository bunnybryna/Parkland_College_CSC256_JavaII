package lab1Pack;

public class LifeInsurance extends Insurance {
    private int age;
    private double life;
    
    public LifeInsurance(String theName, int theAge, double theLife)
    {
        super(theName);
        age = theAge;
        life = theLife;
        commission = life * 0.2;
    }
    
    // setters
    public void setAge(int theAge)
    {
        age = theAge;
    }
    public void setLife(double theLife)
    {
        life = theLife;
    }
    
    // getters
    public int getAge()
    {
        return age;
    }
    public double getLife()
    {
        return life;
    }
    
    //toString 
    public String toString()
    {
        return ("Name of insured : " + nameInsured + "\nAge : "+ age +"\nLife coverage : " + life + "\nCommission : " + commission);
    }

}
