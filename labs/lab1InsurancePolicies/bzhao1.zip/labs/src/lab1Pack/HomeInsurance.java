package lab1Pack;

public class HomeInsurance extends Insurance{
    private double footage;
    private double dwelling;
    private double contents;
    private double liability;
    
    public HomeInsurance(String theName, double theFootage, double theDwelling, double theContents, double theLiability)
    {
        super(theName);
        footage = theFootage;
        dwelling = theDwelling;
        contents = theContents;
        liability = theLiability;
        commission = (liability * 0.3) + ( (dwelling + contents) * 0.2);
    }
    // setters
    public void setFootage(double theFootage)
    {
        footage = theFootage;   
    }    
    public void setDwelling(double theDwelling)
    {
        dwelling = theDwelling;
    }
    public void setContents(double theContents)
    {
        contents = theContents;
    }
    public void setLiability(double theLiability)
    {
        liability = theLiability;
    }
    
    // getters
    public double getFootage()
    {
        return footage;
    }
    public double getDwelling()
    {
        return dwelling;
    }
    public double getContents()
    {
        return contents;
    }
    public double getLiability()
    {
        return liability;
    }
    
    //toString
    public String toString()
    {
        return ("Name of insured : " + nameInsured + "\nHouse footage : " + footage + "\nDwelling coverage : " + dwelling + "\nContents coverage : " + contents + "\nLiability : " + liability + "\nCommission : " + commission);
    }
}
