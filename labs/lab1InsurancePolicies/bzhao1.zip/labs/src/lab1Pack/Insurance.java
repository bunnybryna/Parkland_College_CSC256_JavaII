package lab1Pack;

public class Insurance {

    protected String nameInsured;
    protected double commission;
    
    // default constructor
    public Insurance()
    {
        nameInsured = "Null";
        commission = 0;
    }
    // overload constructor
    public Insurance(String theName)
    {
        nameInsured = theName;
    }
    
    // setters
    public void setName(String theName)
    {
        nameInsured = theName;
    }
    public void setCommission(double theCommission)
    {
        commission = theCommission;
    }
    
    // getters
    public String getName()
    {
        return nameInsured;
    }
    
    public double getCommission()
    {
        return commission;
    }
    
    // toString
    public String toString()
    {
        return ("Name of insured : " + nameInsured + "\nCommission : " + commission); 
    }
    
}
