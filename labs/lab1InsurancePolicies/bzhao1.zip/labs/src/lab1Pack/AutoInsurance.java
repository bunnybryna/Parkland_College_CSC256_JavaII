package lab1Pack;

public class AutoInsurance extends Insurance{
    private String makeModel;
    private double liability;
    private double collision;
    
    public AutoInsurance(String theName, String theModel, double theLiability, double theCollision)
    {
        super(theName);
        makeModel = theModel;
        liability = theLiability;
        collision = theCollision;
        // overrides parent's version
        commission = (liability + collision) * 0.3;
    }        
    
    // setters
    public void setModel(String theModel)
    {
        makeModel = theModel;
    }
    public void setLiability(double theLiability)
    {
        liability = theLiability;
    }
    public void setCollision(double theCollision)
    {
        collision = theCollision;
    }
    
    // getters
    public String getModel()
    {
        return makeModel;
    }
    public double getLiability()
    {
        return liability;
    }
    public double getCollision()
    {
        return collision;
    }

    
    //toString 
    public String toString()
    {
        return ("Name of insured : " + nameInsured + "\nMake and Model : " + makeModel + "\nLiability coverage : " + liability + "\nCollision coverage : " + collision + "\nCommission : " + commission);
    }
}
