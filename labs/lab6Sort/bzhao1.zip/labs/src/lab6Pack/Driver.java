package lab6Pack;

public class Driver {

	public static void main(String[] args) {
		Group g = new Group();
		g.addStudent();
		g.sortScore();

	}

}
